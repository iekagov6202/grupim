
import XLSX from "xlsx";
import { VBA_RULES } from "./vba-rules.mjs";

export function cleanCode(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim().replace(/\s+/g, "").replace(/,/g, "").replace(/\./g, "");
}
export function numeric(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (value === null || value === undefined || value === "") return 0;
  const n = Number(String(value).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}
function vbaKey(fullHS, hsNum) {
  for (const rule of VBA_RULES) {
    const exactHit = rule.exact.includes(fullHS);
    const rangeHit = rule.ranges.some(([a,b]) => hsNum >= a && hsNum <= b);
    if (exactHit || rangeHit) return `${fullHS.slice(0, rule.prefixLength)}-${rule.rate}%`;
  }
  return `${fullHS.slice(0,4)}-#`;
}
function cellText(cell) {
  if (cell === null || cell === undefined) return "";
  if (typeof cell === "object" && cell.text !== undefined) return String(cell.text);
  if (typeof cell === "object" && cell.richText) return cell.richText.map(x=>x.text).join("");
  return String(cell);
}
export function processWorkbook(buffer, opts = {}) {
  const workbook = XLSX.read(buffer, {type:"buffer", cellDates:false, raw:false, dense:false});
  const requested = opts.sheetName || workbook.SheetNames[0];
  const sheetName = workbook.SheetNames.includes(requested) ? requested : workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) throw new Error("Nuk u gjet fleta e zgjedhur në Excel.");
  const rows = XLSX.utils.sheet_to_json(sheet, {header:1, defval:"", raw:false});
  if (rows.length < 2) throw new Error("Fleta nuk përmban rreshta artikujsh.");
  const headers = rows[0].map(cellText);
  const norm = headers.map(x=>String(x).trim().toLowerCase());
  const findCol = (names, fallback) => {
    const idx = norm.findIndex(x=>names.includes(x));
    return idx >= 0 ? idx : fallback;
  };
  // Confirmed from the user's sample invoice and VBA constants: tariff is J (zero-based 9).
  const col = {
    item: findCol(["item no.","item no","item"],0),
    desc: findCol(["description","përshkrimi"],1),
    qty: findCol(["qty","quantity","sasia"],2),
    brutto: findCol(["kg brutto","gross weight"],6),
    netto: findCol(["kg netto","net weight"],7),
    tariff: findCol(["tarrif no.","tariff no.","tariff no","hs code"],9),
    amount: findCol(["amount total","total amount","amount"],11)
  };
  const mode = opts.groupBy || "vba";
  const validate = opts.validate !== false;
  const groups = new Map();
  const issues = [];
  let accepted = 0;
  for (let r=1; r<rows.length; r++) {
    const row = rows[r] || [];
    if (row.every(v=>String(v ?? "").trim()==="")) continue;
    const originalCode = cellText(row[col.tariff]);
    const fullHS = cleanCode(originalCode);
    if (!fullHS) {
      if (validate) issues.push({row:r+1, code:"", message:"Kodi tarifor bosh"});
      continue;
    }
    if (!/^\d{4,12}$/.test(fullHS)) {
      if (validate) issues.push({row:r+1, code:originalCode, message:"Format i kodit tarifor nuk është numerik (4–12 shifra)"});
      continue;
    }
    const hsNum = Number(fullHS.slice(0,6));
    let key, rate;
    if (mode === "hs5" || mode === "hs6") {
      const n = mode === "hs5" ? 5 : 6;
      key = fullHS.slice(0,n);
      rate = "";
    } else {
      key = vbaKey(fullHS, hsNum);
      rate = key.split("-").at(-1);
    }
    const desc = cellText(row[col.desc]).trim();
    const qty = numeric(row[col.qty]);
    const gross = numeric(row[col.brutto]);
    const net = numeric(row[col.netto]);
    const amount = numeric(row[col.amount]);
    if (!groups.has(key)) groups.set(key,{key, rate, qty:0, gross:0, net:0, amount:0, descs:new Map(), maxCode:fullHS, maxNum:Number(fullHS), rows:0});
    const g=groups.get(key);
    g.qty+=qty; g.gross+=gross; g.net+=net; g.amount+=amount; g.rows++; accepted++;
    g.descs.set(desc,(g.descs.get(desc)||0)+qty);
    if (Number(fullHS)>g.maxNum) { g.maxNum=Number(fullHS); g.maxCode=fullHS; }
  }
  const result = [...groups.values()].map(g=>{
    const priority = g.maxCode.replace(/\./g,"").startsWith("8708") ? 0 : 1;
    const description = [...g.descs.entries()].map(([d,q])=>`${d} ${q}Cp`).join(", ");
    return {code:g.maxCode, description, quantity:g.qty, gross:g.gross, net:g.net, amount:g.amount, group:g.key, rate:g.rate, sourceRows:g.rows, priority};
  }).sort((a,b)=>a.priority-b.priority || Number(a.code)-Number(b.code));
  return {sheetName, headers, columns:col, mode, totalInputRows:rows.length-1, acceptedRows:accepted, groupCount:result.length, issues, rows:result, sourceRows:rows};
}
export function makeGroupedWorkbook(inputBuffer, processed) {
  const wb = XLSX.read(inputBuffer,{type:"buffer",cellDates:false,raw:false});
  const ws = wb.Sheets[processed.sheetName];
  const source = processed.sourceRows;
  const lastRow = source.length;
  const start = lastRow + 2; // blank row, then header (Excel 1-based)
  const out = [
    ["KODI NK","GRUPIM SIPAS KODEVE DHE TARIFAVE TE NJEJTA","SASIA","","","","Kg brutto","Kg netto","","","","VLERA TOTALE","HS Group","TARIFA"]
  ];
  for (const r of processed.rows) {
    out.push([r.code,r.description,r.quantity,"","","",r.gross,r.net,"","","",r.amount,r.group,r.rate]);
  }
  const range = XLSX.utils.decode_range(ws["!ref"] || "A1");
  const origin = {r:start,c:0};
  XLSX.utils.sheet_add_aoa(ws,out,{origin});
  const newRange = XLSX.utils.decode_range(ws["!ref"]);
  for (let rr=start; rr<=newRange.e.r; rr++) {
    const c=ws[XLSX.utils.encode_cell({r:rr,c:0})];
    if (c) c.t="s";
    const m=ws[XLSX.utils.encode_cell({r:rr,c:12})];
    if (m) m.t="s";
  }
  wb.Sheets[processed.sheetName]=ws;
  return XLSX.write(wb,{type:"buffer",bookType:"xlsx",compression:true});
}
