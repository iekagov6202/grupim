
import { processWorkbook, makeGroupedWorkbook } from "./engine.mjs";
export const config = { api: { bodyParser: false } };
async function readBody(req){const a=[];for await(const c of req)a.push(c);return Buffer.concat(a);}
function parse(buffer,boundary){const raw=buffer.toString("latin1"),parts=raw.split(`--${boundary}`),f={};for(const p of parts){const i=p.indexOf("\r\n\r\n");if(i<0)continue;const h=p.slice(0,i),b=p.slice(i+4).replace(/\r\n--?$/,""),n=(h.match(/name="([^"]+)"/)||[])[1];if(!n)continue;if(/filename="/.test(h))f.file=Buffer.from(b,"latin1");else f[n]=b.trim();}return f;}
export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).end();
 try{const ct=req.headers["content-type"]||"",b=(ct.match(/boundary=(?:"([^"]+)"|([^;]+))/)||[]).slice(1).find(Boolean);if(!b)throw new Error("Multipart i pavlefshëm");
 const f=parse(await readBody(req),b);if(!f.file)throw new Error("Mungon Excel-i");
 const p=processWorkbook(f.file,{sheetName:f.sheetName,groupBy:f.groupBy,validate:f.validate!=="false"});
 const out=makeGroupedWorkbook(f.file,p);
 res.setHeader("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
 res.setHeader("Content-Disposition",'attachment; filename="Eagle-Customs-Grouped.xlsx"');return res.status(200).send(out);
 }catch(e){return res.status(400).json({error:e.message});}
}
