
import { processWorkbook } from "./engine.mjs";
export const config = { api: { bodyParser: false } };
async function readBody(req) {
  const chunks=[]; for await (const c of req) chunks.push(c); return Buffer.concat(chunks);
}
function parseMultipart(buffer, boundary) {
  const raw=buffer.toString("latin1");
  const marker=`--${boundary}`;
  const parts=raw.split(marker);
  const fields={};
  for (const part of parts) {
    const ix=part.indexOf("\r\n\r\n"); if(ix<0) continue;
    const head=part.slice(0,ix); const body=part.slice(ix+4).replace(/\r\n--?$/,"");
    const name=(head.match(/name="([^"]+)"/)||[])[1];
    if(!name) continue;
    if(/filename="/.test(head)) fields.file=Buffer.from(body,"latin1");
    else fields[name]=body.trim();
  }
  return fields;
}
export default async function handler(req,res) {
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  try {
    const ct=req.headers["content-type"]||"";
    const boundary=(ct.match(/boundary=(?:"([^"]+)"|([^;]+))/)||[]).slice(1).find(Boolean);
    if(!boundary) return res.status(400).json({error:"Kërkesa duhet të jetë multipart/form-data."});
    const fields=parseMultipart(await readBody(req),boundary);
    if(!fields.file) return res.status(400).json({error:"Nuk u dërgua skedari Excel."});
    const result=processWorkbook(fields.file,{sheetName:fields.sheetName,groupBy:fields.groupBy,validate:fields.validate!=="false"});
    return res.status(200).json({ok:true,...result});
  } catch(e) { return res.status(400).json({error:e.message||"Gabim gjatë analizës."}); }
}
