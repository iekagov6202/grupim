
import PDFDocument from "pdfkit";
import { processWorkbook } from "./engine.mjs";
export const config = { api: { bodyParser: false } };
async function readBody(req){const a=[];for await(const c of req)a.push(c);return Buffer.concat(a);}
function parse(buffer,boundary){const raw=buffer.toString("latin1"),parts=raw.split(`--${boundary}`),f={};for(const p of parts){const i=p.indexOf("\r\n\r\n");if(i<0)continue;const h=p.slice(0,i),b=p.slice(i+4).replace(/\r\n--?$/,""),n=(h.match(/name="([^"]+)"/)||[])[1];if(!n)continue;if(/filename="/.test(h))f.file=Buffer.from(b,"latin1");else f[n]=b.trim();}return f;}
export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).end();
 try{
 const ct=req.headers["content-type"]||"",b=(ct.match(/boundary=(?:"([^"]+)"|([^;]+))/)||[]).slice(1).find(Boolean);if(!b)throw new Error("Multipart i pavlefshëm");
 const f=parse(await readBody(req),b);if(!f.file)throw new Error("Mungon Excel-i");
 const p=processWorkbook(f.file,{sheetName:f.sheetName,groupBy:f.groupBy,validate:f.validate!=="false"});
 const doc=new PDFDocument({size:"A4",layout:"landscape",margin:28,bufferPages:true});
 const chunks=[];doc.on("data",c=>chunks.push(c));doc.on("end",()=>{const out=Buffer.concat(chunks);res.setHeader("Content-Type","application/pdf");res.setHeader("Content-Disposition",'attachment; filename="Eagle-Customs-Grouped-A4.pdf"');res.status(200).send(out);});
 doc.fontSize(15).font("Helvetica-Bold").text("Eagle Customs Grouping",{align:"center"});
 doc.moveDown(.3).fontSize(8).font("Helvetica").text(`Fleta: ${p.sheetName} | Rreshta të përpunuar: ${p.acceptedRows} | Grupe: ${p.groupCount}`,{align:"center"});
 doc.moveDown();
 const widths=[65,300,48,65,65,70], headers=["Kodi tarifor","Përshkrimi","Sasia","Kg bruto","Kg netto","Vlera"];
 const x0=28; let y=doc.y; const rowH=22;
 function drawHeader(){let x=x0;doc.font("Helvetica-Bold").fontSize(7);headers.forEach((h,i)=>{doc.rect(x,y,widths[i],rowH).fillAndStroke("#e9eef6","#aab5c5");doc.fillColor("#172033").text(h,x+3,y+7,{width:widths[i]-6});x+=widths[i];});y+=rowH;}
 drawHeader();
 for(const r of p.rows){
   if(y>doc.page.height-48){doc.addPage({size:"A4",layout:"landscape",margin:28});y=28;drawHeader();}
   const vals=[r.code,r.description,String(r.quantity),r.gross.toFixed(2),r.net.toFixed(2),r.amount.toFixed(2)];
   let x=x0;doc.font("Helvetica").fontSize(7).fillColor("#172033");
   vals.forEach((v,i)=>{doc.rect(x,y,widths[i],rowH).stroke("#d5dce6");doc.text(v,x+3,y+6,{width:widths[i]-6,height:rowH-8,ellipsis:true});x+=widths[i];});y+=rowH;
 }
 doc.end();
 }catch(e){return res.status(400).json({error:e.message});}
}
